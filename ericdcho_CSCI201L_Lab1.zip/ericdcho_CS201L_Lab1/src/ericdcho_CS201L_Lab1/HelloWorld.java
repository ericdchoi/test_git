package ericdcho_CS201L_Lab1;

public class HelloWorld {
	public static void main (String[]args) {
		String s = "Hello World";
		s = null;
		s.length();
	}
}
